import numpy as np
from models.meta_classifier import MetaClassifier
from models.claim_extractor import ClaimExtractor
from models.retriever import HybridRetriever
from models.verifier import NLIVerifier
from models.scorer import compute_hallucination_score
from utils.span_localizer import localize_spans
from config.settings import TOP_K
from models.wiki_retriever import WikiRetriever

RELEVANCE_THRESHOLD = 0.35

class HallucinationDetector:

    def __init__(self):
        self.claim_extractor = ClaimExtractor()
        self.retriever = WikiRetriever()
        self.verifier = NLIVerifier()
        self.meta_classifier = MetaClassifier()

    def analyze(self, question, response):

        sentences = self.claim_extractor.split_sentences(response)
        results = []
        scores = []

        for sentence in sentences:

            if not sentence.strip():
                continue

            claim_units = self.claim_extractor.extract_claim_units(sentence)

            evidence, relevance_score = self.retriever.retrieve(sentence)

            # 🚫 No Evidence Handling
            if evidence is None or relevance_score < RELEVANCE_THRESHOLD:
                results.append({
                    "sentence": sentence,
                    "hallucinated_spans": [],
                    "score": 0.2,
                    "label": "not_verifiable",
                    "evidence": "No relevant evidence found on Wikipedia."
                })
                scores.append(0.2)
                continue

            # Run NLI
            nli_probs = self.verifier.verify(evidence, sentence)
            label = max(nli_probs, key=nli_probs.get)
# ------added for interpretability------
            features = {
            "contradiction_prob": nli_probs["contradiction"],
            "neutral_prob": nli_probs["neutral"],
            "entailment_prob": nli_probs["entailment"],
            "relevance_score": relevance_score,
            "num_claim_units": len(claim_units),
            "sentence_length": len(sentence.split())
            }

            # score = (
            #     0.7 * nli_probs["contradiction_prob"] +
            #     0.3 * nli_probs["neutral_prob"]
            # )

            score = self.meta_classifier.predict(features)

            hallucinated_spans = localize_spans(
                sentence, evidence, claim_units
            )

            results.append({
                "features": features,
                "sentence": sentence,
                "hallucinated_spans": hallucinated_spans,
                "score": float(score),
                "label": label,
                "evidence": evidence[:1000]
            })

            scores.append(score)

        return {
            "sentences": results,
            "overall_score": float(sum(scores) / len(scores)) if scores else 0
        }