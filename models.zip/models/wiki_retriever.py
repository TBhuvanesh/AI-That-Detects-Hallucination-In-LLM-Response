import wikipedia
from sentence_transformers import SentenceTransformer, util
import torch

class WikiRetriever:
    def __init__(self):
        self.embed_model = SentenceTransformer("BAAI/bge-large-en")

    def search_wikipedia(self, query, top_k=3):
        try:
            pages = wikipedia.search(query, results=top_k)
        except Exception:
            return []

        documents = []

        for title in pages:
            try:
                page = wikipedia.page(title)
                content = page.content[:5000]  # limit size
                paragraphs = content.split("\n")
                # Filter out empty paragraphs
                documents.extend([p.strip() for p in paragraphs if p.strip()])
            except Exception:
                continue

        return documents

    def retrieve(self, query, top_k=3):
        documents = self.search_wikipedia(query, top_k)

        if not documents:
            return None, 0.0

        try:
            query_embedding = self.embed_model.encode(query, convert_to_tensor=True)
            doc_embeddings = self.embed_model.encode(documents, convert_to_tensor=True)

            scores = util.cos_sim(query_embedding, doc_embeddings)[0]

            top_idx = torch.argmax(scores).item()
            best_score = scores[top_idx].item()
            best_doc = documents[top_idx]

            return best_doc, best_score
        except Exception as e:
            print(f"Error during retrieval: {e}")
            return None, 0.0