# def localize_spans(sentence, evidence, claim_units):

#     hallucinated_spans = []

#     for num in claim_units["numbers"]:
#         if num not in evidence:
#             hallucinated_spans.append(num)

#     for ent_text, _ in claim_units["entities"]:
#         if ent_text not in evidence:
#             hallucinated_spans.append(ent_text)

#     return hallucinated_spans




def localize_spans(sentence, evidence, claim_units):

    hallucinated_spans = []

    evidence_lower = evidence.lower()

    for num in claim_units["numbers"]:
        if num not in evidence:
            hallucinated_spans.append(num)

    for ent_text, _ in claim_units["entities"]:
        if ent_text.lower() not in evidence_lower:
            hallucinated_spans.append(ent_text)

    return list(set(hallucinated_spans))